from pymongo import MongoClient
from bson.objectid import ObjectId
from pprint import pprint

class AnimalShelter(object):
    '''CRUD operations for Animal collection in MongoDB'''

    def initialize(self, username, password):
        # Initializing the MongoClient. This helps to 
        # access the MongoDB databases and collections. 
        self.client = MongoClient('mongodb://%s:%s@localhost:41763/AAC' % (username, password))
        self.database = self.client['AAC']

    def create(self, data):
        #Create method for CRUD functionality
        #Returns true if successful, false otherwise
        if data is not None:
            self.database.animals.insert(data) #data should be dictionary
            success = True
        else:
            raise Exception("Nothing to save, because data parameter is empty")
            success = False
        return success
  
    def read(self, arg):
        #Read method for CRUD functionality
        #Returns cursor to data found
        if arg is not None:
            data = self.database.animals.find(arg,{"_id":False})
        else:
            data = self.database.animals.find({},{"_id":False})
        return data
    
    def update(self, arg, data):
        #Update method for CRUD functionality
        #Returns pretty printed result in json format of all updated entries
        if data is not None:
            result = self.database.animals.update_many(arg, data)
            message = list(self.database.animals.find(arg,{"_id":False}))
            pprint(message)
        else:
            raise Exception("Arg value not found")
        return message

    def delete(self, arg):
        #Delete method for CRUD functionality
        #Returns pretty printed result in json format of all deleted entries
        if arg is not None:
            message = list(self.database.animals.find(arg,{"_id":False}))
            if message != []:
                result = self.database.animals.delete_many(arg)
                pprint(message)
            else:
                raise Exception("Arg value not found")
            return message
                
        
        